import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.AbstractBorder;

public class OthelloClientGUI extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String HOST = "localhost";
    private static final int PORT = 5050;

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    private JButton[][] cells = new JButton[8][8];
    private JLabel statusLabel = new JLabel("Connecting...");
    private JLabel scoreLabel = new JLabel("Score: ");
    private String myColor = "?";
    private String currentTurn = "?";
    private boolean myTurn = false;
    private String line; 
    private char[] emptyRow = {'.','.','.','.','.','.','.','.'};
    private JLabel playerNameLabel = new JLabel("Player ...");
    private JTextField joinCodeField = new JTextField(6);
    private JButton aiBtn = new JButton("Play vs AI");
    private JButton hostBtn = new JButton("Host Game");
    private JButton joinBtn = new JButton("Join Game");
    private JButton passBtn = new JButton("Pass");
    private JButton endCurrGameBtn = new JButton("End Game");
    private JButton quitBtn = new JButton("Quit");
    private int bCount = 0;
    private int wCount = 0;
    private String roomCode = null;
   
    
    public OthelloClientGUI() {
        super("Othello Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 850);
        setLayout(new BorderLayout());

        JPanel boardPanel = new JPanel(new GridLayout(8, 8));
        //boardPanel.setBackground(Color.MAGENTA);
        Font font = new Font("Arial", Font.BOLD, 18);
        
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                JButton btn = new JButton(".");
                btn.setFont(font);
                btn.setFocusPainted(false);
                btn.setBorder(new RoundedBorder(10));
                btn.setBackground(Color.pink);
                int row = r, col = c;
                btn.addActionListener(e -> handleCellClick(row, col, btn));
                cells[r][c] = btn;
                boardPanel.add(btn);
            }
        }

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.add(statusLabel, BorderLayout.CENTER);
        bottom.add(scoreLabel, BorderLayout.EAST);
        
        JPanel top = new JPanel(new BorderLayout());
        top.add(playerNameLabel, BorderLayout.CENTER);

        add(boardPanel, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);
        
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());

        // Add buttons
        topPanel.add(aiBtn);
        topPanel.add(hostBtn);

        // Join Section
        topPanel.add(new JLabel("Join Code:"));
        topPanel.add(joinCodeField);
        topPanel.add(joinBtn);
        topPanel.add(passBtn);
        topPanel.add(endCurrGameBtn);
        topPanel.add(quitBtn);

        // Add topPanel to frame
        add(topPanel, BorderLayout.NORTH);
        aiBtn.addActionListener(e -> {
        	out.println("RESET");
        	try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	out.println("MODE AI");
            statusLabel.setText("Starting game vs AI...");
            setEndGameBtnStatus(true);
            setJoinBtnStatus(false);
            setJoinCodeFieldStatus(false);
            setHostBtnStatus(false);
            setPassBtnStatus(true);
            setAIBtnStatus(false);
        });

        hostBtn.addActionListener(e -> {
        	out.println("MODE HUMAN");
            statusLabel.setText("Hosting game... getting room code");
        });

        joinBtn.addActionListener(e -> {
            String code = joinCodeField.getText().trim();
            if (!code.isEmpty()) {
            	out.println("join " + code);
                statusLabel.setText("Joining room: " + code);
            } else {
                statusLabel.setText("Enter a room code!");
            }
        });
        
        passBtn.addActionListener(e -> {
            out.println("PASS");
            
        });
        
        endCurrGameBtn.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to end the current game?",
                    "End Game?",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (choice == JOptionPane.YES_OPTION) {
                out.println("END_GAME");
                statusLabel.setText("Game ended by player.");
                setEndGameBtnStatus(false);
                setPassBtnStatus(false);
                clearBoardRows();
                setJoinBtnStatus(true);
                setJoinCodeFieldStatus(true);
                setHostBtnStatus(true);
                setAIBtnStatus(true);
            } else {
                statusLabel.setText("Game not ended.");
            }
        });
        
        quitBtn.addActionListener(e -> {
            out.println("quit");
            System.exit(0);
        });
        
        connectToServer();
        setVisible(true);
        setEndGameBtnStatus(false);
        setPassBtnStatus(false);
    }

    private void connectToServer() {
        new Thread(() -> {
            try {
                socket = new Socket(HOST, PORT);
                System.out.println("Connected to server " + HOST + ":" + PORT);
                
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);
                statusLabel.setText("Connected to server...");
                char[][] board = new char[8][8];
                while ((line = in.readLine()) != null) {
                   try {
							processMessage(line, board);
						} catch (IOException e) {
							e.printStackTrace();
						}
                }
            } catch (IOException e) {
                SwingUtilities.invokeLater(() -> statusLabel.setText("Connection closed."));
            }
        }).start();
    }

    private void processMessage(String line, char[][] board) throws IOException {
    	String[] parts = line.split("\\s+");
    	System.out.println("Server line >> " + line);
        if (parts.length==0) return;
        switch (parts[0]) {
        	case "PLAYER_NAME":
        		playerNameLabel.setText("Player "+parts[1]);
                break;
        	case "WAITING_FOR_PLAYER":
        		statusLabel.setText("Waiting for opponent...");
                break;
            case "START":
                if (parts.length>=3 && parts[1].equals("COLOR")) {
                	myColor = parts[2];
                    System.out.println("OthelloGame started. You are " + myColor);
                    statusLabel.setText("OthelloGame started. You are " + myColor);
                    setEndGameBtnStatus(true);
                    setJoinBtnStatus(false);
                    setJoinCodeFieldStatus(false);
                    setHostBtnStatus(false);
                    setAIBtnStatus(false);
                    setPassBtnStatus(true);
                }
                break;
            case "BOARD":
                if (parts.length>=1) {
                	board = new char[8][8];
                	String row = parts[1];
                	System.out.println("Part1 >> "+row);
                	boolean allSet = false;
                	for (int r=0;r<8;r++) {
                		System.out.println(row);
                		if (row == null) continue;
                		else if (row.startsWith("BOARD "))
                			row = row.substring(row.indexOf("BOARD ")+6);
                        if (Arrays.equals(emptyRow, row.toCharArray())) {
                        	row = in.readLine();
                        	continue;
                        }
                       if (board[r][0] == 0) {
                        	if(containsBAndW(row.toCharArray())) {
                        		 for (int c = 0; c < 8; c++) {
                        			 char c1 = (row.toCharArray())[c];
                        			 if(isBOrW(c1) ) {
                        				 board[r][c] = c1;
                        				 allSet = true;
                        			 }
                        		}
                        	}
                            
                           
                        } 
                        row = in.readLine();
                    }
                    
                    if (allSet) printBoard(board);
                    scoreLabel.setText("Score: B=" + bCount + " W=" + wCount);
                 
                } else {
                    System.out.println(line);
                }
                break;
            case "SCORE":
                if (parts.length>=3) {
                	scoreLabel.setText("Score: B=" + parts[1] + " W=" + parts[2]);                	
                }
                break;
                
            case "TURN":
            	currentTurn = parts[1];
                statusLabel.setText("Turn: " + currentTurn);
                break;
            case "ROOM_CODE":
            	roomCode = parts[1];
                statusLabel.setText("Room Code to Join game, share this with your friend : " + roomCode);
                JOptionPane.showMessageDialog(this,
                        "Room created! Share this code: " + roomCode,
                        "Room Created", JOptionPane.INFORMATION_MESSAGE);
                break;   
            case "YOUR_TURN":
            	setMyTurn(true);
                statusLabel.setText("[ACTION] Your turn (" + myColor + ")");
                break;
            case "INVALID_MOVE":
            	JOptionPane.showConfirmDialog(
                        this,
                        "Invalid move, try again!!",
                        "Invalid Move..",
                        JOptionPane.CLOSED_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );
            	statusLabel.setText("Invalid move, try again.");
            	setMyTurn(true);  
                break;
            case "MOVE_MADE":
            	statusLabel.setText("Move made: " + parts[1] + " " + parts[2] + " " + parts[3]);
                // clear board buffer so fresh BOARD will re-fill and print
                clearBoardRows();
                break;
            case "PASS":
            	statusLabel.setText("Player " + parts[1] + " has no moves and passes.");
            	clearBoardRows();
                break;
            case "GAME_OVER":
                JOptionPane.showMessageDialog(this, line, "Game Over", JOptionPane.INFORMATION_MESSAGE);
                setMyTurn(false);
                setJoinBtnStatus(true);
                setJoinCodeFieldStatus(true);
                setHostBtnStatus(true);
                setAIBtnStatus(true);
                break;
            case "OPPONENT_DISCONNECTED":
                JOptionPane.showMessageDialog(this, "Opponent disconnected", "Game Ended", JOptionPane.WARNING_MESSAGE);
                setMyTurn(false);
                break;
            case "GAME_ENDED_BY_PLAYER":
                JOptionPane.showMessageDialog(this, "Game Ended by Player!!", "Game Ended", JOptionPane.WARNING_MESSAGE);
                setMyTurn(false);
                setJoinBtnStatus(true); 
                setJoinCodeFieldStatus(true);
                setHostBtnStatus(true);
                setAIBtnStatus(true);
                break;    
            case "MESSAGE":
            	statusLabel.setText("Press 'Play vs AI' for play against AI, 'Host' to create a room and 'join Code' to join a friend");
                break;
            default:
            	statusLabel.setText(" " + line);
        }
    }

    private void handleCellClick(int r, int c, JButton btn) {
        if (!isMyTurn()) {
            statusLabel.setText("Not your turn!");
            return;
        }
        out.println("MOVE " + r + " " + c);
        setMyTurn(false); // wait for server response
    }

    private void updateButtonColor(JButton btn, char ch) {
        if (ch == 'B') btn.setBackground(Color.BLACK);
        else if (ch == 'W') btn.setBackground(Color.WHITE);
        else btn.setBackground(Color.GREEN);
    }
    
    private void setMyTurn(boolean myTurn) {
    	System.out.println("Turn >> "+this.myTurn);
    	this.myTurn = myTurn;
    }
    private boolean isMyTurn() {
    	return myTurn;
    }
    
    private void clearBoardRows() { 
    	printBoard(new char[8][8]);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(OthelloClientGUI::new);
    }
    
    private void printBoard(char[][] board) {
        System.out.println(board);
        bCount = 0;
        wCount = 0;
        for (int r=0;r<8;r++) {
            for (int c=0;c<8;c++) {
                char cc = board[r][c];
                //if (cc!=0) {
                	if (cc == 'B')
                		++bCount;
                	else if (cc == 'W')
                		++wCount;
                	else
                		cc = '.';
                	cells[r][c].setText(cc+"");
                    updateButtonColor(cells[r][c], cc);
                //}
                
            }
        }
    }
    
    public static boolean containsBAndW(char[] arr) {
        boolean foundB = false;
        boolean foundW = false;

        // Loop through the array
        for (char c : arr) {
            if (c == 'B') {
                foundB = true;
            }
            if (c == 'W') {
                foundW = true;
            }

            // If both 'B' and 'W' are found, no need to continue checking
            if (foundB || foundW) {
                return true;
            }
        }

        // Return false if either 'B' or 'W' is missing
        return false;
    }
    
    public static boolean isBOrW(char c) {
        // Regular expression to match 'B' or 'W'
        return Pattern.matches("[BW]", String.valueOf(c));
    }
    
    private static class RoundedBorder extends AbstractBorder {
        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private int radius;

        public RoundedBorder(int radius) {
            this.radius = radius;
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius, this.radius, this.radius, this.radius);
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.setColor(Color.BLACK);
            g.drawRoundRect(x, y, width - 1, height - 1, radius, radius);  // Draw the rounded rectangle
        }
    }
    
    private void setJoinBtnStatus(boolean status) {
    	joinBtn.setEnabled(status);
    }
    
    private void setEndGameBtnStatus(boolean status) {
    	endCurrGameBtn.setEnabled(status);
    }
    
    private void setPassBtnStatus(boolean status) {
    	passBtn.setEnabled(status);
    }
    
    private void setHostBtnStatus(boolean status) {
    	hostBtn.setEnabled(status);
    }
    
    private void setAIBtnStatus(boolean status) {
    	aiBtn.setEnabled(status);
    }
    
    private void setJoinCodeFieldStatus(boolean status) {
    	joinCodeField.setText("");
    	joinCodeField.setEnabled(status);
    }
}
