import java.util.*;

public class OthelloBoard {
    private final char[][] board = new char[8][8];

    public OthelloBoard() {
        for (char[] row : board) {
            Arrays.fill(row, '.');
        }
        // Standard Othello starting position
        board[3][3] = 'W';
        board[3][4] = 'B';
        board[4][3] = 'B';
        board[4][4] = 'W';
    }

    public String[] toStrings() {
        String[] rows = new String[8];
        for (int i = 0; i < 8; i++) {
            rows[i] = new String(board[i]);
        }
        return rows;
    }

    public int count(char color) {
        int cnt = 0;
        for (char[] row : board) {
            for (char c : row) {
                if (c == color) cnt++;
            }
        }
        return cnt;
    }

    public boolean hasAnyMove(char color) {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                if (board[r][c] == '.' && isLegal(color, r, c)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isLegal(char color, int r, int c) {
        if (!inBounds(r, c) || board[r][c] != '.') return false;

        char opp = (color == 'B') ? 'W' : 'B';
        int[] dr = {-1,-1,-1,0,0,1,1,1};
        int[] dc = {-1,0,1,-1,1,-1,0,1};

        for (int d = 0; d < 8; d++) {
            int rr = r + dr[d];
            int cc = c + dc[d];
            int flips = 0;
            while (inBounds(rr, cc) && board[rr][cc] == opp) {
                rr += dr[d];
                cc += dc[d];
                flips++;
            }
            if (flips > 0 && inBounds(rr, cc) && board[rr][cc] == color) {
                return true;
            }
        }
        return false;
    }

    public boolean makeMove(char color, int r, int c) {
        if (!isLegal(color, r, c)) return false;

        char opp = (color == 'B') ? 'W' : 'B';
        board[r][c] = color;

        int[] dr = {-1,-1,-1,0,0,1,1,1};
        int[] dc = {-1,0,1,-1,1,-1,0,1};

        for (int d = 0; d < 8; d++) {
            int rr = r + dr[d];
            int cc = c + dc[d];
            List<int[]> flips = new ArrayList<>();

            while (inBounds(rr, cc) && board[rr][cc] == opp) {
                flips.add(new int[]{rr, cc});
                rr += dr[d];
                cc += dc[d];
            }

            if (inBounds(rr, cc) && board[rr][cc] == color) {
                for (int[] f : flips) {
                    board[f[0]][f[1]] = color;
                }
            }
        }
        return true;
    }

    public List<int[]> getLegalMoves(char color) {
        List<int[]> moves = new ArrayList<>();
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                if (board[r][c] == '.' && isLegal(color, r, c)) {
                    moves.add(new int[]{r, c});
                }
            }
        }
        return moves;
    }

    private boolean inBounds(int r, int c) {
        return r >= 0 && r < 8 && c >= 0 && c < 8;
    }
}
