public interface GameSession {
    void handleCommand(PlayerHandler player, String line);
    void playerDisconnected(PlayerHandler player);
    void endCurrentGame(PlayerHandler player);
}

