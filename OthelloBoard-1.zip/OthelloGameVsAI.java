import java.util.List;
import java.util.Random;

public class OthelloGameVsAI implements Runnable, GameSession {
    private final PlayerHandler human;
    private OthelloBoard board = new OthelloBoard();
    private final Random random = new Random();
    private char humanColor = 'B';
    private char aiColor = 'W';
    private char current = 'B';
    private boolean finished = false;
    
    public OthelloGameVsAI(PlayerHandler human) {
    	this.human = human;
    }

    @Override
    public void run() {
        human.send("START COLOR " + humanColor);
        sendTurn();
    }

    private void sendTurn() {
        if (finished) return;

        broadcastBoard();
        human.send("TURN " + current);

        if (current == humanColor) {
            human.send("YOUR_TURN");
        } else {
            playAIMove();
        }
    }

    private void broadcastBoard() {
        String[] rows = board.toStrings();
        for (int i = 0; i < 8; i++) {
            human.send("BOARD " + rows[i]);
        }
        int b = board.count('B');
        int w = board.count('W');
        human.send("SCORE " + b + " " + w);
    }

    private void playAIMove() {
        if (finished) return;
        
        try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        if (!board.hasAnyMove(aiColor)) {
            if (!board.hasAnyMove(humanColor)) {
                endGame();
                return;
            } else {
                human.send("PASS " + aiColor);
                current = humanColor;
                sendTurn();
                return;
            }
        }

        List<int[]> moves = board.getLegalMoves(aiColor);
        if (moves.isEmpty()) {
            human.send("PASS " + aiColor);
            current = humanColor;
            sendTurn();
            return;
        }

        int[] move = moves.get(random.nextInt(moves.size()));
        int r = move[0];
        int c = move[1];
        board.makeMove(aiColor, r, c);

        human.send("MOVE_MADE " + aiColor + " " + r + " " + c);

        if (!board.hasAnyMove(humanColor) && !board.hasAnyMove(aiColor)) {
        	broadcastBoard();
            endGame();
        } else {
            current = humanColor;
            sendTurn();
        }
    }

    @Override
    public synchronized void handleCommand(PlayerHandler player, String line) {
    	if (line.contains("RESET") && finished) 
    		finished = false;
    	
    	if (finished || player != human) return;

        if (line.startsWith("MOVE")) {
            if (current != humanColor) {
                human.send("ERROR not_your_turn");
                return;
            }
            String[] parts = line.split("\\s+");
            if (parts.length != 3) return;

            int r, c;
            try {
                r = Integer.parseInt(parts[1]);
                c = Integer.parseInt(parts[2]);
            } catch (NumberFormatException e) {
                human.send("ERROR invalid_coordinates");
                return;
            }

            if (!board.makeMove(humanColor, r, c)) {
                human.send("INVALID_MOVE");
            } else {
                human.send("MOVE_MADE " + humanColor + " " + r + " " + c);

                if (!board.hasAnyMove(humanColor) && !board.hasAnyMove(aiColor)) {
                	broadcastBoard();
                    endGame();
                } else {
                    current = aiColor;
                    sendTurn();
                }
            }
        } else if (line.equalsIgnoreCase("RESET")) {
        	board = new OthelloBoard();
        	sendTurn();
        } 
        else if (line.equalsIgnoreCase("PASS")) {
        	current = aiColor;
            sendTurn();
        }  
        else if (line.equalsIgnoreCase("QUIT")) {
            playerDisconnected(player);
        }
        else if (line.equalsIgnoreCase("END_GAME")) {
        	endCurrentGame(player);
        }
    }

    private void endGame() {
        finished = true;
        int b = board.count('B');
        int w = board.count('W');
        if (b > w) {
            human.send("GAME_OVER Player B WON!! Final Score :: B-" + b + " W-" + w);
        } else if (w > b) {
            human.send("GAME_OVER Player W WON!! Final Score :: B-" + b + " W-" + w);
        } else {
            human.send("GAME_OVER DRAW!! Final Score :: B-" + b + " W-" + w);
        }
        
    }

    @Override
    public void playerDisconnected(PlayerHandler player) {
        finished = true;
        // No other player to notify in AI mode
    }
    
    @Override
    public void endCurrentGame(PlayerHandler player) {
        // Send to both players
    	human.send("GAME_ENDED_BY_PLAYER "+player.getColor());
        board = new OthelloBoard();

        System.out.println("Game ended by: " + player.getColor());
    }
}
