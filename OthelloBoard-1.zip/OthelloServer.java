import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OthelloServer {
    private static final int PORT = 5050;
    private static final ExecutorService pool = Executors.newCachedThreadPool();

    // roomCode -> host player
    private static final Map<String, PlayerHandler> rooms = new HashMap<>();
    private static final Random random = new Random();

    private static int playerCounter = 1;
    private static int gameCounter = 1;

    public static void main(String[] args) throws IOException {
        System.out.println("Othello Server running on port " + PORT);
        try (ServerSocket listener = new ServerSocket(PORT)) {
            while (true) {
                Socket client = listener.accept();
                int id = playerCounter++;
                System.out.println("New client connected. Assigned Player ID = " + id);
                PlayerHandler handler = new PlayerHandler(client, id);
                pool.execute(handler);
            }
        }
    }

    public static synchronized void createRoomForPlayer(PlayerHandler host) {
        String code;
        if (host.getGame() != null) {
        	removeFromRooms(host);
        }
        do {
            code = String.format("%04d", random.nextInt(10000));
        } while (rooms.containsKey(code));
        rooms.put(code, host);
        host.send("ROOM_CODE " + code);
        host.send("MESSAGE Share this code with your friend. They must type: join " + code);
        System.out.println("Player " + host.getId() + " created room " + code);
    }

    public static synchronized void joinRoom(PlayerHandler joiner, String code) {
        PlayerHandler host = rooms.remove(code);
        if (host == null) {
            joiner.send("ROOM_NOT_FOUND " + code);
            System.out.println("Player " + joiner.getId() + " tried to join invalid room " + code);
            return;
        }

        int gameId = gameCounter++;
        System.out.println("Starting Game #" + gameId +
                " between Player " + host.getId() + " (Black) and Player " + joiner.getId() + " (White) in room " + code);

        OthelloGame game = new OthelloGame(host, joiner);
        host.setGame(game, 'B');
        joiner.setGame(game, 'W');

        host.send("ROOM_JOINED " + code);
        joiner.send("ROOM_JOINED " + code);

        pool.execute(game);
    }

    public static void startVsAI(PlayerHandler player) {
        System.out.println("Player " + player.getId() + " starting game vs AI.");
        OthelloGameVsAI game = new OthelloGameVsAI(player);
        player.setGame(game, 'B');
        pool.execute(game);
    }

    public static synchronized void removeFromRooms(PlayerHandler p) {
        rooms.values().removeIf(v -> v == p);
    }
    
}
