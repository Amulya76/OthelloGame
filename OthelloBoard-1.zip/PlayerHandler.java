import java.io.*;
import java.net.Socket;

public class PlayerHandler implements Runnable {
    private final Socket socket;
    private final int id;
    private BufferedReader in;
    private PrintWriter out;
    private GameSession game;
    private char color;

    public PlayerHandler(Socket socket, int id) {
        this.socket = socket;
        this.id = id;
    }

    @Override
    public void run() {
        try {
            in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            System.out.println("Player " + id + " connected.");

            send("WELCOME");
            send("CHOOSE_MODE");
            send("MESSAGE Type: 'ai' for computer opponent, 'host' to create a room, 'join CODE' to join a friend.");

            String line;
            while ((line = in.readLine()) != null) {
                System.out.println("From player " + id + ": " + line);
                if (game != null) {
                    game.handleCommand(this, line);
                } else {
                    handleLobbyCommand(line.trim());
                }
            }
        } catch (IOException e) {
            System.out.println("Player " + id + " I/O error: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
            if (game != null) {
                game.playerDisconnected(this);
            }
            OthelloServer.removeFromRooms(this);
            System.out.println("Player " + id + " disconnected.");
        }
    }

    private void handleLobbyCommand(String line) {
        if (line.equalsIgnoreCase("MODE AI") || line.equalsIgnoreCase("AI")) {
            OthelloServer.startVsAI(this);
        } else if (line.equalsIgnoreCase("MODE HUMAN") || line.equalsIgnoreCase("HOST")) {
            OthelloServer.createRoomForPlayer(this);
        } else if (line.toUpperCase().startsWith("JOIN")) {
            String[] parts = line.split("\\s+");
            if (parts.length >= 2) {
                String code = parts[1].trim();
                OthelloServer.joinRoom(this, code);
            } else {
                send("MESSAGE Usage: join CODE");
            }
        } else if (line.equalsIgnoreCase("QUIT")) {
            try {
                socket.close();
            } catch (IOException ignored) {}
        } else {
            send("MESSAGE In lobby. Commands: 'ai', 'host', 'join CODE', 'quit'");
        }
    }

    public void send(String msg) {
        out.println(msg);
    }

    public void setGame(GameSession g, char c) {
        this.game = g;
        this.color = c;
    }
    public GameSession getGame() {
        return this.game;
    }

    public char getColor() {
        return color;
    }

    public int getId() {
        return id;
    }
}
