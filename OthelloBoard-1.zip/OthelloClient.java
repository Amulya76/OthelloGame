import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class OthelloClient {
    private static final String HOST = "localhost";
    private static final int PORT = 5050;
    private static int boardRowIndex = 0;

    public static void main(String[] args) {
        try (Socket socket = new Socket(HOST, PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connected to Othello Server.");
            char[][] board = new char[8][8];

            Thread reader = new Thread(() -> {
                try {
                    String line;
                    while ((line = in.readLine()) != null) {
                        handleServerLine(line, board);
                    }
                } catch (IOException e) {
                    System.out.println("Connection closed.");
                }
            });
            reader.setDaemon(true);
            reader.start();

            System.out.println("Commands:");
            System.out.println("  ai           - play against computer");
            System.out.println("  host         - create a room (get room code)");
            System.out.println("  join CODE    - join a friend's room");
            System.out.println("  row col      - make a move once game starts (e.g., 2 3)");
            System.out.println("  quit         - exit");

            while (true) {
                String input = scanner.nextLine().trim();
                if (input.equalsIgnoreCase("quit")) {
                    out.println("QUIT");
                    break;
                } else if (input.equalsIgnoreCase("ai")) {
                    out.println("MODE AI");
                } else if (input.equalsIgnoreCase("host")) {
                    out.println("MODE HUMAN");
                } else if (input.toLowerCase().startsWith("join")) {
                    String[] parts = input.split("\\s+");
                    if (parts.length >= 2) {
                        out.println("JOIN " + parts[1]);
                    } else {
                        System.out.println("Usage: join CODE");
                    }
                } else if (input.matches("\\d+\\s+\\d+")) {
                    out.println("MOVE " + input);
                } else {
                    System.out.println("Unknown command. Use: ai | host | join CODE | row col | quit");
                }
            }
        } catch (IOException e) {
            System.out.println("Unable to connect: " + e.getMessage());
        }
    }

    private static void handleServerLine(String line, char[][] board) {
        if (line.startsWith("BOARD ")) {
            String rowStr = line.substring(6);
            if (boardRowIndex >= 0 && boardRowIndex < 8) {
                board[boardRowIndex] = rowStr.toCharArray();
                boardRowIndex++;
            }
            if (boardRowIndex == 8) {
                printBoard(board);
                boardRowIndex = 0;
            }
        } else {
            System.out.println(line);
        }
    }

    private static void printBoard(char[][] b) {
        System.out.println("  0 1 2 3 4 5 6 7");
        for (int i = 0; i < 8; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < 8; j++) {
                char ch = b[i][j];
                if (ch == 0) ch = '.';
                System.out.print(ch + " ");
            }
            System.out.println();
        }
    }
}
