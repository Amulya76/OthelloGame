public class OthelloGame implements Runnable, GameSession {
    private final PlayerHandler blackPlayer;
    private final PlayerHandler whitePlayer;
    private OthelloBoard board = new OthelloBoard();
    private PlayerHandler current;
    private boolean finished = false;

    public OthelloGame(PlayerHandler black, PlayerHandler white) {
    	this.blackPlayer = black;
        this.whitePlayer = white;
        this.current = black;
    }

    @Override
    public void run() {
        blackPlayer.send("START COLOR B");
        whitePlayer.send("START COLOR W");
        sendTurn();
    }

    private void sendTurn() {
        if (finished) return;

        broadcastBoard();
        blackPlayer.send("TURN " + current.getColor());
        whitePlayer.send("TURN " + current.getColor());
        current.send("YOUR_TURN");
    }

    private void broadcastBoard() {
        String[] rows = board.toStrings();
        for (int i = 0; i < 8; i++) {
            blackPlayer.send("BOARD " + rows[i]);
            whitePlayer.send("BOARD " + rows[i]);
        }
        int b = board.count('B');
        int w = board.count('W');
        blackPlayer.send("SCORE " + b + " " + w);
        whitePlayer.send("SCORE " + b + " " + w);
    }

    @Override
    public synchronized void handleCommand(PlayerHandler player, String line) {
    	if (line.contains("RESET") && finished) 
    		finished = false;
        
        if (finished) return;

        if (line.startsWith("MOVE")) {
            if (player != current) {
                player.send("ERROR not_your_turn");
                return;
            }
            String[] parts = line.split("\\s+");
            if (parts.length != 3) return;

            int r, c;
            try {
                r = Integer.parseInt(parts[1]);
                c = Integer.parseInt(parts[2]);
            } catch (NumberFormatException e) {
                player.send("ERROR invalid_coordinates");
                return;
            }

            if (!board.makeMove(player.getColor(), r, c)) {
                player.send("INVALID_MOVE");
                if (!board.hasAnyMove(player.getColor())) {
                	advanceTurn();
                }
            } else {
                blackPlayer.send("MOVE_MADE " + player.getColor() + " " + r + " " + c);
                whitePlayer.send("MOVE_MADE " + player.getColor() + " " + r + " " + c);
                advanceTurn();
            }
        }else if (line.equalsIgnoreCase("PASS")) {
        	advanceTurn();
        }  
        else if (line.equalsIgnoreCase("RESET")) {
        	board = new OthelloBoard();
        	sendTurn();
        } 
        else if (line.equalsIgnoreCase("QUIT")) {
            playerDisconnected(player);
        }
        else if (line.equalsIgnoreCase("END_GAME")) {
        	endCurrentGame(player);
        }
    }

    private void advanceTurn() {
        current = (current == blackPlayer) ? whitePlayer : blackPlayer;
        char color = current.getColor();

        if (!board.hasAnyMove(color)) {
            blackPlayer.send("PASS " + color);
            whitePlayer.send("PASS " + color);
            current = (current == blackPlayer) ? whitePlayer : blackPlayer;

            if (!board.hasAnyMove(current.getColor())) {
            	broadcastBoard();
                endGame();
                return;
            }
        }
        sendTurn();
    }

    private void endGame() {
        finished = true;
        int b = board.count('B');
        int w = board.count('W');
        if (b > w) {
            broadcast("GAME_OVER Player B WON!! Final Score :: B-" + b + " W-" + w);
        } else if (w > b) {
            broadcast("GAME_OVER Player W WON!! Final Score :: B-" + b + " W-" + w);
        } else {
            broadcast("GAME_OVER DRAW!! Final Score :: B-" + b + " W-" + w);
        }
    }
    
    private void broadcast(String msg) {
        blackPlayer.send(msg);
        whitePlayer.send(msg);
    }

    @Override
    public void playerDisconnected(PlayerHandler player) {
        if (finished) return;
        finished = true;
        PlayerHandler other = (player == blackPlayer) ? whitePlayer : blackPlayer;
        other.send("OPPONENT_DISCONNECTED");
    }
    
    @Override
    public void endCurrentGame(PlayerHandler player) {
        // Send to both players
    	blackPlayer.send("GAME_ENDED_BY_PLAYER "+player.getColor());
        whitePlayer.send("GAME_ENDED_BY_PLAYER "+player.getColor());

        board = new OthelloBoard();

        System.out.println("Game ended by: " + player.getColor());
    }
}
